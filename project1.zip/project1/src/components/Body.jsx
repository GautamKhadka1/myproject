import React from 'react';
import './index.css';
function Body(){
    return(
        <div id="bg">
      <div id="content"><h1>Welcome to the website</h1>
      <div>Hello my name is Mr.Gautam Khadka.</div>
      </div>
      <div><img src='element.png' id="png" alt='element'/></div>
      </div>
    );
}
export default Body;
import React from 'react';
import './index.css';
function Footer(){
    return(
        <footer>
        ©GautamKhadka, {new Date().getFullYear()}
      </footer>
    );
}
export default Footer;